﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace singinlogin
{
    public partial class Form7 : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-C533VLE\SQLDEVELOPER;Initial Catalog=EMPLOYEES_TERMINAL;Integrated Security=True");//ссылка на базу данных
        
        SqlCommand cmd;//пременная SqlCommand
        public Form7()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        DateBase dateBase = new DateBase();

       

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "eMPLOYEES_TERMINALDataSet4.PersonalVisit". При необходимости она может быть перемещена или удалена.
            this.personalVisitTableAdapter3.Fill(this.eMPLOYEES_TERMINALDataSet4.PersonalVisit);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "eMPLOYEES_TERMINALDataSet2.PersonalVisit". При необходимости она может быть перемещена или удалена.
           


        }

        private void button1_Click(object sender, EventArgs e)
        {
            int selectedUserID = (int)dataGridView1.CurrentRow.Cells["iDvisitDataGridViewTextBoxColumn"].Value;

            int selectedRowID = (int)dataGridView1.CurrentRow.Cells["iDvisitDataGridViewTextBoxColumn"].Value;

            // Получение статуса пользователя в таблице User_visit
            int userVisitStatus = 0;
            string selectUserVisitQuery = "SELECT Статус FROM User_visit WHERE ID_user = @UserID";
            using (SqlConnection connection = new SqlConnection(conn.ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(selectUserVisitQuery, connection))
                {
                    command.Parameters.AddWithValue("@UserID", selectedRowID);
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            userVisitStatus = (int)reader["Статус"];
                        }
                    }
                    connection.Close();
                }
            }


            // Проверка статуса пользователя и обновление таблицы PersonalVisit
            if (userVisitStatus == 0)
            {
                string updatePersonalVisitQuery = "UPDATE PersonalVisit SET Статус = 'одобрена' WHERE ID_visit = @ID";
                using (SqlConnection connection = new SqlConnection(conn.ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(updatePersonalVisitQuery, connection))
                    {
                        command.Parameters.AddWithValue("@ID", selectedRowID);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result > 0)
                        {
                            
                            MessageBox.Show("Одобрено!", "Одобрено", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            else if (userVisitStatus == 1)
            {
                string updatePersonalVisitQuery = "UPDATE PersonalVisit SET Статус = 'отказ' WHERE ID_visit = @ID";
                using (SqlConnection connection = new SqlConnection(conn.ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(updatePersonalVisitQuery, connection))
                    {
                        command.Parameters.AddWithValue("@ID", selectedRowID);
                        connection.Open();
                        int result = command.ExecuteNonQuery();
                        connection.Close();
                        if (result > 0)
                        {
                            
                            MessageBox.Show("Отказано! Пользователь находится в чёрном списке!", "Отказано", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            
        }


        private void button2_Click(object sender, EventArgs e)
        {
            int selectedUserID = (int)dataGridView1.CurrentRow.Cells["iDvisitDataGridViewTextBoxColumn"].Value;

            // Получение ID выбранной строки в DataGridView
            int selectedRowID = (int)dataGridView1.CurrentRow.Cells["iDvisitDataGridViewTextBoxColumn"].Value;

            // Создание SQL-запроса для обновления поля "Статус" в таблице "PersonalVisit"
            string sqlQuery = "UPDATE PersonalVisit SET Статус = 'отказ' WHERE ID_visit = @ID";

            // Создание экземпляра SqlCommand с параметрами SQL-запроса и соединения с базой данных
            using (SqlConnection connection = new SqlConnection(conn.ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Добавление параметра @ID в экземпляр SqlCommand
                    command.Parameters.AddWithValue("@ID", selectedRowID);

                    // Открытие соединения с базой данных
                    connection.Open();

                    // Выполнение SQL-запроса
                    int result = command.ExecuteNonQuery();

                    // Закрытие соединения с базой данных
                    connection.Close();

                    // Обновление DataGridView, чтобы отобразить изменения в таблице
                    if (result > 0)
                    {
                        
                        MessageBox.Show("Отказано","Отказано", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

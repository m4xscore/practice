﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace singinlogin
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "eMPLOYEES_TERMINALDataSet5.PersonalVisit". При необходимости она может быть перемещена или удалена.
            this.personalVisitTableAdapter1.Fill(this.eMPLOYEES_TERMINALDataSet5.PersonalVisit);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "eMPLOYEES_TERMINALDataSet3.PersonalVisit". При необходимости она может быть перемещена или удалена.
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            personalVisitBindingSource1.MoveNext();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            personalVisitBindingSource1.MovePrevious();
            
        }
    }
}

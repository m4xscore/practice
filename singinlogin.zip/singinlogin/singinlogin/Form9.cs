﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace singinlogin
{
    public partial class Form9 : Form
    {
         DateBase dateBase = new DateBase();
        public Form9()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
        }
        private void textBoxlogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            textBoxlogin.MaxLength = 50;
            textBoxlogin.KeyPress += new KeyPressEventHandler(textBoxlogin_KeyPress);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            var loginUser = textBoxlogin.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select  Код from securiti where Код = '{loginUser}'";
            SqlCommand command = new SqlCommand(querystring, dateBase.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count == 1)
            {

                MessageBox.Show("Вы успешно вошли!", " ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form8 frm8 = new Form8();
                this.Hide();
                frm8.ShowDialog();
                this.Show();

            }
            else
                MessageBox.Show("Неправильный код!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}

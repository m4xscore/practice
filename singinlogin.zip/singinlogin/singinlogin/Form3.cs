﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace singinlogin
{
    public partial class Form3 : Form
    {
        private void Form3_Load(object sender, EventArgs e)
        {

            textBoxpassword1.PasswordChar = '*';
            textBoxlogin1.MaxLength = 50;
            textBoxpassword1.MaxLength = 50;
        }
        DateBase dateBase = new DateBase();
        public Form3()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }
        private void button2_Click(object sender, EventArgs e)
        {        
            var login = textBoxlogin1.Text;
            var password = textBoxpassword1.Text;

            string querystring = $"insert into register(login_user, password_user) values('{login}', '{password}')";

            SqlCommand command = new SqlCommand(querystring,dateBase.getConnection());
            dateBase.openconnection();

            if (checkuser())
            {
                return;
            }

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Аккаунт создан!", "Успех!");
                Form1 frm1 = new Form1();
                this.Hide();
                frm1.ShowDialog();
            }
            else
            {
                MessageBox.Show("Аккаунт не создан!");
            }
            dateBase.closeconnection();
        }
        private Boolean checkuser()
        {
            var loginUser = textBoxlogin1.Text;
            var passUser = textBoxpassword1.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            string querystring = $"select id_user, login_user, password_user from register where login_user = '{loginUser}' and password_user = '{passUser}'";
            
            SqlCommand command = new SqlCommand(querystring, dateBase.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if(table.Rows.Count > 0)
            {
                MessageBox.Show("Аккаунт уже существует!");
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace singinlogin
{
    public partial class Form4 : Form
    {
        private int _userId;

        public int userId
        {
            get { return _userId; }
            set { _userId = value; }
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-C533VLE\SQLDEVELOPER;Initial Catalog=EMPLOYEES_TERMINAL;Integrated Security=True");//ссылка на базу данных
        string imgLocation = "";//пременная стринг
        SqlCommand cmd;//пременная SqlCommand
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*/*)|*/*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imgLocation = dialog.FileName.ToString();
                pictureBox1.ImageLocation = imgLocation;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null || string.IsNullOrEmpty(comboBox2.Text) || dateTimePicker1.Value == null || dateTimePicker2.Value == null || string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Заполните все поля, обязательные для ввода.");
                return;
            }


            byte[] images = null;
            FileStream Streem = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
            BinaryReader brs = new BinaryReader(Streem);
            images = brs.ReadBytes((int)Streem.Length);

            conn.Open();
            string sqlQuery = "INSERT INTO PersonalVisit (С, ПО, Цель_посещения, Подразделение, ФИО, Фамилия, Имя, Отчество,Телефон, E_mail, Организация, Примечание, Дата_рождения, Серия, Номер, Фото, ID_user) " +
                "VALUES (@dateTimePicker1, @dateTimePicker2, @comboBox1, @comboBox2, @textBox1, @textBox2, @textBox3, @textBox4, @textBox5, @textBox6, @textBox7, @textBox8, @dateTimePicker3,@textBox9, @textBox10, @images, @userID)";
            cmd = new SqlCommand(sqlQuery, conn);
            cmd.Parameters.AddWithValue("@dateTimePicker1", dateTimePicker1.Value);
            cmd.Parameters.AddWithValue("@dateTimePicker2", dateTimePicker2.Value);
            cmd.Parameters.AddWithValue("@comboBox1", comboBox1.Text);
            cmd.Parameters.AddWithValue("@comboBox2", comboBox2.Text);
            cmd.Parameters.AddWithValue("@textBox1", textBox1.Text);
            cmd.Parameters.AddWithValue("@textBox2", textBox2.Text);
            cmd.Parameters.AddWithValue("@textBox3", textBox3.Text);
            cmd.Parameters.AddWithValue("@textBox4", textBox4.Text);
            cmd.Parameters.AddWithValue("@textBox5", textBox5.Text);
            cmd.Parameters.AddWithValue("@textBox6", textBox6.Text);
            cmd.Parameters.AddWithValue("@textBox7", textBox7.Text);
            cmd.Parameters.AddWithValue("@textBox8", textBox8.Text);
            cmd.Parameters.AddWithValue("@dateTimePicker3", dateTimePicker3.Value);
            cmd.Parameters.AddWithValue("@textBox9", textBox9.Text);
            cmd.Parameters.AddWithValue("@textBox10", textBox10.Text);
            cmd.Parameters.AddWithValue("@images", images);
            cmd.Parameters.AddWithValue("@userID", _userId);
            int N = cmd.ExecuteNonQuery();

            conn.Close();

            MessageBox.Show("Данные сохранены. Ожидайте одобрения вашей заявки нашими сотрудниками в ближайщее время!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            pictureBox1.Image = null;
            imgLocation = "";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;




namespace singinlogin
{
    internal class DateBase
    {
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=DESKTOP-C533VLE\SQLDEVELOPER;Initial Catalog=EMPLOYEES_TERMINAL;Integrated Security=True");
        public void openconnection()
        {
            if(sqlConnection.State == System.Data.ConnectionState.Closed)
            {
                sqlConnection.Open();
            }
        }
        public void closeconnection()
        {
            if (sqlConnection.State == System.Data.ConnectionState.Open)
            {
                sqlConnection.Close();
            }
        }
        public SqlConnection getConnection()
        {
            return sqlConnection;
        }

    }
}

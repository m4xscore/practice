﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace singinlogin
{
    public partial class Form6 : Form
    {
        DateBase dateBase = new DateBase();
        public Form6()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var loginUser = textBoxlogin.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select  Код from Employees where Код = '{loginUser}'";
            SqlCommand command = new SqlCommand(querystring, dateBase.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count == 1)
            {
                
                MessageBox.Show("Вы успешно вошли!", " ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form7 frm7= new Form7();
                this.Hide();
                frm7.ShowDialog();
                this.Show();

            }
            else
                MessageBox.Show("Вы ввели неправильный код!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        private void textBoxlogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }
        private void Form6_Load(object sender, EventArgs e)
        {
            textBoxlogin.MaxLength = 50;
            textBoxlogin.KeyPress += new KeyPressEventHandler(textBoxlogin_KeyPress);
        }
    }
}

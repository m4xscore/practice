﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace singinlogin
{
    public partial class Form1 : Form
    {
        public int userId;
        DateBase dateBase = new DateBase();

        public Form1()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            textBoxpassword.PasswordChar = '*';
            textBoxlogin.MaxLength = 50;
            textBoxpassword.MaxLength = 50;
        }

        public void button2_Click(object sender, EventArgs e)
        {
            var loginUser = textBoxlogin.Text;
            var passUser = textBoxpassword.Text;           

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"select Логин, Пароль, BlacklistedDate, BlacklistedReason, ID_user from User_visit where Логин = '{loginUser}' and Пароль = '{passUser}'";
            SqlCommand command = new SqlCommand(querystring, dateBase.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count == 1)
            {
                // пользователь найден
                if (table.Rows[0]["BlacklistedDate"] == DBNull.Value)
                {
                    // пользователь не находится в черном списке
                    MessageBox.Show("Вы успешно вошли!", " ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    userId = Convert.ToInt32(table.Rows[0]["ID_user"]);
                    Form4 frm4 = new Form4();
                    frm4.userId = userId;
                    this.Hide();
                    frm4.ShowDialog();
                    this.Show();
                }
                else
                {
                    // пользователь находится в черном списке
                    DateTime blacklistedDate = Convert.ToDateTime(table.Rows[0]["BlacklistedDate"]);
                    string blacklistedReason = Convert.ToString(table.Rows[0]["BlacklistedReason"]);
                    string message = $"Ошибка входа: пользователь заблокирован с {blacklistedDate.ToShortDateString()} по причине: {blacklistedReason}";
                    MessageBox.Show(message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (table.Rows.Count == 0)
            {
                // пользователь не найден или заблокирован
                MessageBox.Show("Ошибка входа: пользователь не найден или заблокирован", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form3 frm_sign = new Form3();
            frm_sign.Show();
            this.Hide();
        }
    }
}
